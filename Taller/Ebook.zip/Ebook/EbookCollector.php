<?php

include_once('Ebook.php');
include_once('Collector.php');

class EbookCollector extends Collector
{
  
  function showEbooks() {
    $rows = self::$db->getRows("SELECT * FROM ebook ");        
    $arrayEbook= array();        
    foreach ($rows as $c){
      $aux = new Ebook($c{'idEbook'},$c{'titulo'},$c{'autor'},$c{'precio'},$c{'idioma'}, 
      	$c{'numero_Paginas'}, $c{'categoria'}, $c{'isbn'}, $c{'editorial'}, $c{'traductor'});
      array_push($arrayEbook, $aux);
    }
    return $arrayEbook;        
  }

}
?>