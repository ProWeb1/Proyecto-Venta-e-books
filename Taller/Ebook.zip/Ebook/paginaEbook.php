<?php
include_once("EbookCollector.php");

$id =1;

$EbookCollectorObj = new EbookCollector();

foreach ($EbookCollectorObj->showEbooks() as $c){
  echo "<div>";
  echo "<br/> Id: " . $c->getidEbook() . "<br/>" .$c->gettitulo() . "<br/>" .$c->getautor() . "<br/>" .
  		$c->getprecio() . "<br/>" .$c->getidioma() . "<br/>" .$c->getnumero_Paginas() . "<br/>" .
  		$c->getcategoria() . "<br/>" .$c->getisbn() . "<br/>" .$c->geteditorial() . "<br/>" . $c->gettraductor();                                     
  		
  echo "</div>"; 
}


?>
