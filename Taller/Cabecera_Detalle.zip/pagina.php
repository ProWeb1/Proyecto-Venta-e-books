<?php
require_once("CabeceraCollector.php");
require_once("DetalleCollector.php");


$CabeceraCollectorObj = new CabeceraCollector();
$DetalleCollectorObj = new DetalleCollector();

echo ('<b>CABECERAS</b> <br />');
foreach ($CabeceraCollectorObj->showCabeceras() as $c){
  echo "<div>";
  echo "ID: " .$c->getIdCabecera() .
  		"<br />USUARIO: " .$c->getUsuario() .
  		"<br />FECHA: " .$c->getFecha() .
  		"<br />TOTAL: " .$c->getTotal();
  echo "</div>"; 
  echo "<br />";
}

echo ('<b>DETALLES</b> <br />');

foreach ($DetalleCollectorObj->showDetalles() as $c){
  echo "<div>";
  echo "ID: " .$c->getIdDetalle() .
  		"<br />CODIGO CABECERA: " .$c->getCabecera() .
  		"<br />LINEA: " .$c->getLinea();                                   
  echo "</div>"; 
  echo "<br />";
}
//die('...');
?>