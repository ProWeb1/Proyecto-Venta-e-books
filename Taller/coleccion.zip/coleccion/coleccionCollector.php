<?php

include_once('coleccion.php');
include_once('Collector.php');

class ColeccionCollector extends Collector
{
  
  function showColeccion() {
    $rows = self::$db->getRows("SELECT * FROM coleccion ");        
    $arrayColeccion= array();        
    foreach ($rows as $c){
      $aux = new Coleccion($c{'idColeccion'},$c{'descripcion'});
	  $arrayColeccion[] = $aux;
    }
    return $arrayColeccion;        
  }

}
?>

