<?php
include_once("coleccionCollector.php");

$id =1;

$ColeccionCollectorObj = new ColeccionCollector();

foreach ($ColeccionCollectorObj->showColeccion() as $c){
  echo "<div>";
  echo "</br>Identificador: " . $c->getidColeccion() . "</br>Nombre: " . $c->getdescripcion();                                     
  echo "</div>"; 
}
?>
