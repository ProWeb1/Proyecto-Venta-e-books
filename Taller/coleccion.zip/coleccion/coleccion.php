<?php

class Coleccion
{
    private $idColeccion;   
		private $descripcion;
   
    
     function __construct($idColeccion, $descripcion) {
       self::setidColeccion($idColeccion);
       self::setdescripcion($descripcion);
     }
    
     function setidColeccion($idColeccion){
       $this->idColeccion = $idColeccion;
     } 
     function getidColeccion(){
       return $this->idColeccion;
     }
     function setdescripcion($descripcion){
       $this->descripcion = $descripcion;
     } 
     function getdescripcion(){
       return $this->descripcion;
     } 
   
}

?> 
