<?php
include_once("PerfilCollector.php");

$id =1;

$PerfilCollectorObj = new PerfilCollector();

foreach ($PerfilCollectorObj->showPerfiles() as $c){
  echo "<div>";
  echo "</br>Identificador: " . $c->getIdPerfil() . "</br>Nombre: " . $c->getNombre() . "</br>Apellido: " . $c->getApellido() . "</br>Fecha de Nacimiento: " . $c->getFechaNacimiento() . "</br>G&eacute;nero: " . $c->getGenero() . "</br>Email: " . $c->getEmail() . "</br>Pa&iacute;s: " . $c->getPais();                                     
  echo "</div>"; 
}
?>
