<?php

class Perfil
{
    private $idPerfil;   
		private $nombre;
    private $apellido;
		private $fechaNacimiento;
		private $genero;
		private $email;
		private $pais;
    
     function __construct($idPerfil, $nombre, $apellido, $fechaNacimiento, $genero, $email, $pais) {
       self::setIdPerfil($idPerfil);
       self::setNombre($nombre);
       self::setApellido($apellido);
			 self::setFechaNacimiento($fechaNacimiento);
			 self::setGenero($genero);
			 self::setEmail($email);
			 self::setPais($pais);
     }
    
     function setIdPerfil($idPerfil){
       $this->idPerfil = $idPerfil;
     } 
     function getIdPerfil(){
       return $this->idPerfil;
     }
     function setNombre($nombre){
       $this->nombre = $nombre;
     } 
     function getNombre(){
       return $this->nombre;
     } 
     function setApellido($apellido){
       $this->apellido = $apellido;
     } 
     function getApellido(){
       return $this->apellido;
     }
		 function setFechaNacimiento($fechaNacimiento){
       $this->fechaNacimiento = $fechaNacimiento;
     } 
     function getFechaNacimiento(){
       return $this->fechaNacimiento;
     } 
		 function setGenero($genero){
       $this->genero = $genero;
     } 
     function getGenero(){
       return $this->genero;
     } 
		 function setEmail($email){
       $this->email = $email;
     } 
     function getEmail(){
       return $this->email;
     } 
		 function setPais($pais){
       $this->pais = $pais;
     } 
     function getPais(){
       return $this->pais;
     }  
}

?> 
