<?php
include_once("UsuarioCollector.php");

$id =1;

$UsuarioCollectorObj = new UsuarioCollector();

foreach ($UsuarioCollectorObj->showUsuarios() as $c){
  echo "<div>";
  echo "</br>Identificador: " . $c->getIdUsuario() . "</br>Usuario: " . $c->getNombre() . "</br>Contrase&ntilde;a: " . $c->getContrasena();                                     
  echo "</div>"; 
}


?>
